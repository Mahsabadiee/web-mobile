import React, { useState } from "react";
import {
  View,
  TextInput,
  Button,
  FlatList,
  TouchableOpacity,
  Text,
} from "react-native";
import axios from "axios";
import styles from "../styles/styles";
//http://192.168.0.106/
const TODO_SERVER_URL = "http://192.168.0.106:3000/api/todos";

const TodoComponent = ({ todos, setTodos }) => {
  const [todo, setTodo] = useState("");
  const [message, setMessage] = useState("");

  const addTodo = () => {
    if (todo.trim()) {
      const newTodo = { text: todo.trim(), completed: false };
      axios
        .post(TODO_SERVER_URL, newTodo)
        .then((response) => {
          setTodos([...todos, response.data]);
          setTodo("");
          setMessage("added");
          setTimeout(() => {
            setMessage("");
          }, 2000);
        })
        .catch((error) => console.log(error));
    }
  };

  const deleteTodo = (id) => {
    axios
      .delete(`${TODO_SERVER_URL}/${id}`)
      .then(() => {
        setTodos(todos.filter((todo) => todo.id !== id));
      })
      .catch((error) => console.log(error));
  };

  return (
    <View style={styles.section}>
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="Add a new task"
          value={todo}
          onChangeText={setTodo}
        />
        <Button color="green" title="Add" onPress={addTodo} />
      </View>
      <FlatList
        data={todos}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <TouchableOpacity onPress={() => deleteTodo(item.id)}>
            <View style={styles.todoItem}>
              <Text>{item.text}</Text>
              <Text style={styles.deleteText}>Delete</Text>
            </View>
          </TouchableOpacity>
        )}
      />
    </View>
  );
};

export default TodoComponent;

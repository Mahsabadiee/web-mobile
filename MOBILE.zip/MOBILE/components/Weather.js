import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  Button,
  TouchableOpacity,
} from "react-native";
import axios from "axios";

const API_KEY = "d7b59d4100e327199a11da5d08293bd5";

const Weather = () => {
  const [city, setCity] = useState("Vaxjo");
  const [weather, setWeather] = useState(null);
  const [showWeather, setShowWeather] = useState(true);

  const fetchWeather = async () => {
    try {
      const response = await axios.get(
        `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_KEY}&units=metric`
      );
      setWeather(response.data);
      setShowWeather(true); // Show weather details after fetching
    } catch (error) {
      console.error(error);
    }
  };

  const toggleWeather = () => {
    setShowWeather(!showWeather); // Toggle showWeather state
  };

  return (
    <View>
      <TouchableOpacity style={styles.titleContainer} onPress={toggleWeather}>
        <Text style={styles.title}>Weather</Text>
      </TouchableOpacity>
      <View style={styles.container}>
        {showWeather && (
          <View style={styles.weatherBox}>
            <View style={styles.inputContainer}>
              <TextInput
                style={styles.input}
                placeholder="Enter city name"
                value={city}
                onChangeText={(text) => setCity(text)}
              />
              <Button title="Show" onPress={fetchWeather} color="green" />
            </View>
            {weather && (
              <View style={styles.weatherContainer}>
                <Text style={styles.weatherText}>Location: {weather.name}</Text>
                <Text style={styles.weatherText}>
                  Temperature: {weather.main.temp.toFixed(0)} °C
                </Text>
                <Text style={styles.weatherText}>
                  Description: {weather.weather[0].description}
                </Text>
              </View>
            )}
          </View>
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 2,
    backgroundColor: "#f0f0f0",
    borderRadius: 15,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.25,
    shadowRadius: 5,
    elevation: 6,
  },
  weatherBox: {
    borderWidth: 1,
    borderColor: "black",
    borderRadius: 10,
    padding: 10,
    width: "100%",
  },
  titleContainer: {
    marginBottom: 5,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
  },
  inputContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 10,
  },
  input: {
    height: 40,
    borderColor: "gray",
    borderWidth: 1,
    width: "70%",
    paddingHorizontal: 8,
  },
  weatherContainer: {
    alignItems: "center",
  },
  weatherText: {
    fontSize: 18,
  },
});

export default Weather;

import React from "react";
import { View, FlatList, Text, StyleSheet } from "react-native";

// Import styles from external file
import styles from "../styles/styles";

const EventComponent = ({ events }) => {
  // Component for item separator
  const ItemSeparator = () => <View style={styles.separator}></View>;

  return (
    <View style={styles.section}>
      <FlatList
        data={events}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.eventItem}>
            <Text style={styles.eventTitle}>{item.title}</Text>
            <Text>{new Date(item.date).toDateString()}</Text>
            <Text>{item.description}</Text>
          </View>
        )}
        ItemSeparatorComponent={ItemSeparator}
      />
    </View>
  );
};

export default EventComponent;

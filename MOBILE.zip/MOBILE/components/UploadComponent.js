// UploadComponent.js

import React from 'react';
import { View, Text, Button, ActivityIndicator, StyleSheet } from 'react-native';
import axios from 'axios';

const UploadComponent = ({ image }) => {
  const [loading, setLoading] = React.useState(false);
  const [uploadStatus, setUploadStatus] = React.useState('');

  const uploadImage = async () => {
    setLoading(true);
    try {
      const formData = new FormData();
      formData.append('image', {
        uri: image.uri,
        type: 'image/jpeg',
        name: 'photo.jpg',
      });

      const response = await axios.post('https://example.com/upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      console.log('Upload response:', response.data);
      setUploadStatus('Image uploaded successfully.');
    } catch (error) {
      console.error('Error uploading image:', error);
      setUploadStatus('Error uploading image.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      {image && (
        <View style={styles.imageContainer}>
          <Text style={styles.label}>Captured Image:</Text>
          <Image source={{ uri: image.uri }} style={styles.image} />
        </View>
      )}
      <Button title="Upload Image" onPress={uploadImage} disabled={!image || loading} />
      {loading && <ActivityIndicator style={styles.loader} size="large" color="#0000ff" />}
      <Text style={styles.status}>{uploadStatus}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  imageContainer: {
    marginBottom: 20,
  },
  label: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  image: {
    width: 300,
    height: 300,
    borderRadius: 10,
  },
  loader: {
    marginTop: 20,
  },
  status: {
    marginTop: 10,
    fontSize: 16,
    fontWeight: 'bold',
    color: 'green',
  },
});

export default UploadComponent;

const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const { Todo } = require("./database");

const app = express();
const port = 3000;

app.use(cors());
app.use(bodyParser.json());

app.get("/api/todos", async (req, res) => {
  try {
    const todos = await Todo.findAll();
    res.json(todos);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch todos" });
  }
});

app.post("/api/todos", async (req, res) => {
  try {
    const newTodo = await Todo.create(req.body);
    res.json(newTodo);
  } catch (error) {
    res.status(500).json({ error: "Failed to create todo" });
  }
});

app.delete("/api/todos/:id", async (req, res) => {
  try {
    const todoId = parseInt(req.params.id, 10);
    await Todo.destroy({ where: { id: todoId } });
    res.sendStatus(204);
  } catch (error) {
    res.status(500).json({ error: "Failed to delete todo" });
  }
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});

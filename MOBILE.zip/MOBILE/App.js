import React, { useState, useEffect } from "react";
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
} from "react-native";
import axios from "axios";
import TodoComponent from "./components/TodoComponent";
import EventComponent from "./components/EventComponent";
import Weather from "./components/Weather";

const TODO_SERVER_URL = "http://192.168.0.106:3000/api/todos";
const EVENT_SERVER_URL = "http://192.168.0.106:3000/api/events";

export default function App() {
  const [todos, setTodos] = useState([]);
  const [events, setEvents] = useState([]);
  const [todoVisible, setTodoVisible] = useState(true);
  const [eventVisible, setEventVisible] = useState(true); 
  const [started, setStarted] = useState(false); 

  useEffect(() => {
    if (started) {
      fetchData(); // Fetch initial data on component mount
    }
  }, [started]);

  const fetchData = () => {
    axios
      .get(TODO_SERVER_URL)
      .then((response) => setTodos(response.data))
      .catch((error) => console.log(error));

    axios
      .get(EVENT_SERVER_URL)
      .then((response) => setEvents(response.data))
      .catch((error) => console.log(error));
  };

  const handleReloadData = () => {
    fetchData();
  };

  if (!started) {
    return (
      <View style={styles.startContainer}>
        <TouchableOpacity
          onPress={() => setStarted(true)}
          style={styles.startButton}
        >
          <Text style={styles.startButtonText}>Personal Organizer</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <TouchableOpacity onPress={() => setTodoVisible(!todoVisible)}>
        <Text style={styles.title}>To-Do List</Text>
      </TouchableOpacity>
      {todoVisible && <TodoComponent todos={todos} setTodos={setTodos} />}

      <TouchableOpacity onPress={() => setEventVisible(!eventVisible)}>
        <Text style={styles.title}>Calendar Events</Text>
      </TouchableOpacity>
      {eventVisible && <EventComponent events={events} setEvents={setEvents} />}

      <TouchableOpacity>
        <Text> </Text>
        <Weather />
      </TouchableOpacity>

      <TouchableOpacity onPress={handleReloadData}>
        <View style={styles.reloadButton}>
          <Text style={styles.reloadButtonText}>Refresh</Text>
        </View>
      </TouchableOpacity>
    </ScrollView>
  );
}










const styles = StyleSheet.create({
  startContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#fff",
  },
  startButton: {
    backgroundColor: "green",
    padding: 20,
    borderRadius: 5,
  },
  startButtonText: {
    color: "white",
    fontSize: 20,
    fontWeight: "bold",
  },
  container: {
    flex: 1,
    backgroundColor: "#fff",
    padding: 40,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 10,
  },
  reloadButton: {
    backgroundColor: "green",
    padding: 10,
    marginTop: 20,
    alignSelf: "center",
    borderRadius: 5,
  },
  reloadButtonText: {
    color: "white",
    fontSize: 16,
    fontWeight: "bold",
  },
});

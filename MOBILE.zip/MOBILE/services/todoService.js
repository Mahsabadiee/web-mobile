import axios from "axios";

const TODO_SERVER_URL = "http://192.168.0.106:3000/api/todos";

export const getTodos = async () => {
  const response = await axios.get(TODO_SERVER_URL);
  return response.data;
};

export const addTodo = async (todo) => {
  const response = await axios.post(TODO_SERVER_URL, todo);
  return response.data;
};

export const deleteTodo = async (id) => {
  await axios.delete(`${TODO_SERVER_URL}/${id}`);
};

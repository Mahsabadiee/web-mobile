import React from "react";
import { Link } from "react-router-dom";
import "./NavigationBar.css";

const NavigationBar = () => {
  return (
    <div className="NavigationBar">
      <div className="nav-container">
        <Link to="/" className="nav-button">
          Home
        </Link>
        <Link to="/tasks" className="nav-button">
          ToDo List
        </Link>
        <Link to="/calendar" className="nav-button">
          Calendar
        </Link>
        <Link to="/weather" className="nav-button">
          Weather
        </Link>
        <Link to="/map" className="nav-button">
          Map
        </Link>
        <Link to="/camera" className="nav-button">
          Camera
        </Link>
      </div>
    </div>
  );
};

export default NavigationBar;

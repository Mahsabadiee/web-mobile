import React, { useState, useEffect } from "react";
import axios from "axios";
import "./MyCalendar.css"; // import CSS file

const SERVER_URL = "http://localhost:3000/api/events";

function Calendar() {
  const [title, setTitle] = useState("");
  const [date, setDate] = useState("");
  const [description, setDescription] = useState("");
  const [events, setEvents] = useState([]);
  const [message, setMessage] = useState("");

  useEffect(() => {
    fetchEvents();
  }, []);

  const fetchEvents = async () => {
    try {
      const response = await axios.get(SERVER_URL);
      setEvents(response.data);
    } catch (error) {
      console.error("Failed to fetch events", error);
    }
  };

  const addEvent = async () => {
    if (title.trim() && date) {
      try {
        const newEvent = {
          title: title.trim(),
          date,
          description: description.trim(),
        };
        const response = await axios.post(SERVER_URL, newEvent);
        setEvents([...events, response.data]);
        setMessage("Event added");
        setTimeout(() => {
          setMessage("");
        }, 2000);
        setTitle("");
        setDate("");
        setDescription("");
      } catch (error) {
        console.error("Failed to add event", error);
      }
    }
  };

  const deleteEvent = async (id) => {
    try {
      await axios.delete(`${SERVER_URL}/${id}`);
      setEvents(events.filter((event) => event.id !== id));
    } catch (error) {
      console.error("Failed to delete event", error);
    }
  };

  return (
    <div className="Calendar">
      {" "}
      {/* Apply CSS className */}
      <h1>Calendar Events</h1>
      <input
        type="text"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Event title"
      />
      <input
        type="date"
        value={date}
        onChange={(e) => setDate(e.target.value)}
      />
      <input
        type="text"
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        placeholder="Event description"
      />
      <button onClick={addEvent}>Add Event</button>
      {message && <p>{message}</p>}
      <ul>
        {events.map((event) => (
          <li key={event.id}>
            {event.title} - {new Date(event.date).toLocaleDateString()} -{" "}
            {event.description}
            <button onClick={() => deleteEvent(event.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Calendar;

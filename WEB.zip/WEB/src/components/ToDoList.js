import React, { useState, useEffect } from "react";
import axios from "axios";
import "./ToDoList.css";

const SERVER_URL = "http://localhost:3000/api/todos";

function ToDoList() {
  const [todo, setTodo] = useState("");
  const [todos, setTodos] = useState([]);
  const [message, setMessage] = useState("");

  useEffect(() => {
    fetchTodos();
  }, []);

  const fetchTodos = async () => {
    try {
      const response = await axios.get(SERVER_URL);
      setTodos(response.data);
    } catch (error) {
      console.error("Failed to fetch todos", error);
    }
  };

  const addTodo = async () => {
    if (todo.trim()) {
      try {
        const newTodo = { text: todo.trim(), completed: false };
        const response = await axios.post(SERVER_URL, newTodo);
        setTodos([...todos, response.data]);
        setMessage("Added");
        setTimeout(() => {
          setMessage("");
        }, 2000);
        setTodo("");
      } catch (error) {
        console.error("Failed to add todo", error);
      }
    }
  };

  const deleteTodo = async (id) => {
    try {
      await axios.delete(`${SERVER_URL}/${id}`);
      setTodos(todos.filter((todo) => todo.id !== id));
    } catch (error) {
      console.error("Failed to delete todo", error);
    }
  };

  return (
    <div className="ToDoList">
      <h1>To-Do List</h1>
      <input
        type="text"
        value={todo}
        onChange={(e) => setTodo(e.target.value)}
        placeholder="Add a new task"
      />
      <button onClick={addTodo}>Add</button>
      {message && <p>{message}</p>}
      <ul>
        {todos.map((todo) => (
          <li key={todo.id}>
            {todo.text}
            <button onClick={() => deleteTodo(todo.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default ToDoList;

// src/components/MapContainer.js
import React, { useEffect, useRef } from "react";
import { GoogleMap, LoadScript, Marker } from "@react-google-maps/api";    //for working with Google Maps.

const containerStyle = {
  width: "100%",
  height: "400px",
};

const center = {
  lat: 56.8,
  lng: 14.8,
};

const MapContainer = () => {
  const mapRef = useRef(null);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const pos = {
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          };
          if (mapRef.current) {
            mapRef.current.panTo(pos);
            new window.google.maps.Marker({
              position: pos,
              map: mapRef.current,
            });
          }
        },
        () => {
          console.log("Error: The Geolocation service failed.");
        }
      );
    } else {
      console.log("Error: Your browser doesn't support geolocation.");
    }
  }, []);

  return (
    <LoadScript googleMapsApiKey="AIzaSyDSc5cKolEV6BSG3JseL4OLc61gjEn-SUw">
      <GoogleMap
        mapContainerStyle={containerStyle}
        center={center}
        zoom={10}
        onLoad={(map) => (mapRef.current = map)}
      >
        <Marker position={center} />
      </GoogleMap>
    </LoadScript>
  );
};

export default MapContainer;

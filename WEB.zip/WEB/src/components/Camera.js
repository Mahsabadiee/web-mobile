import React, { useRef, useState, useEffect } from "react";
import Webcam from "react-webcam";
import axios from "axios"; //for making HTTP requests
import "./Camera.css";

const SERVER_URL = "http://192.168.0.106:3000/api/upload";
const IMAGES_URL = "http://192.168.0.106:3000/api/images";

const WebcamCapture = () => {
  const webcamRef = useRef(null);  //access the webcam
  const [image, setImage] = useState("");   //used to store the captured image
  const [message, setMessage] = useState("");
  const [images, setImages] = useState([]);   //store the list of uploaded images
  const [uploading, setUploading] = useState(false);   //indicate the uploading status

  // Capture a photo from webcam
  const capture = () => {
    const imageSrc = webcamRef.current.getScreenshot();
    setImage(imageSrc);
  };

  // Upload captured photo
  const uploadImage = async () => {
    if (image) {
      try {
        const blob = await fetch(image).then((res) => res.blob());
        const formData = new FormData();
        formData.append("image", blob, "webcam.jpg");

        setUploading(true);

        const response = await axios.post(SERVER_URL, formData, {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        });

        console.log(response.data);
        setMessage("Image uploaded successfully");
        fetchImages();
      } catch (error) {
        console.error("Failed to upload image", error);
        setMessage("Failed to upload image");
      } finally {
        setUploading(false);
        setImage("");
      }
    }
  };

  // Fetch uploaded images
  const fetchImages = async () => {
    try {
      const response = await axios.get(IMAGES_URL);
      setImages(response.data);
    } catch (error) {
      console.error("Failed to fetch images", error);
    }
  };

  useEffect(() => {
    fetchImages();
  }, []);

  return (
    <div className="container">
      <Webcam
        audio={false}
        ref={webcamRef}
        screenshotFormat="image/jpeg"
        width="50%"
        height="50%"
      />
      <button className="button" onClick={capture}>Capture photo</button>
      {image && !uploading && (
        <>
          <img src={image} alt="Captured" className="captured-image" />
          <button className="button" onClick={uploadImage}>Upload</button>
        </>
      )}
      {uploading && <p>Uploading...</p>}
      {message && <p>{message}</p>}
      <div className="images-container">
        {images.map((img, index) => (
          <img key={index} src={`http://192.168.0.106:3000${img}`} alt={`Uploaded ${index}`} className="uploaded-image" />
        ))}
      </div>
    </div>
  );
};

export default WebcamCapture;

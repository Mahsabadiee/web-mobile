import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import "./App.css";
import NavigationBar from "./components/NavigationBar";
import ToDoList from "./components/ToDoList";
import Camera from "./components/Camera";
import MapContainer from "./components/MapContainer";
import MyCalendar from "./components/MyCalendar";
import Weather from "./components/Weather";

function App() {
  return (
    <Router>
      <div className="App">
        <NavigationBar />

        <div className="content-container">
          <div className="content-box">
            <Routes>
              <Route path="/weather" element={<Weather />} />
              <Route path="/tasks" element={<ToDoList />} />
              <Route path="/calendar" element={<MyCalendar />} />
              <Route path="/camera" element={<Camera />} />
              <Route path="/map" element={<MapContainer />} />

              <Route
                path="/"
                element={<h2>This is a personal organizer app </h2>}
              />
            </Routes>
          </div>
        </div>
      </div>
    </Router>
  );
}

export default App;

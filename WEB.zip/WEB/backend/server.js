const express = require("express"); //a framework for building servers
const bodyParser = require("body-parser"); //for parsing the body of requests
const cors = require("cors"); //To handle CORS requests
const multer = require("multer"); //to manage file uploads
const path = require("path"); //to work with file paths
const fs = require("fs"); //to work with the file system
const { Todo, CalendarEvent, sequelize } = require("./database"); //import models and connect to database

const app = express();
const port = 3000;

//cors activation
app.use(cors());
app.use(bodyParser.json());

//Set path for uploaded files.
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

//multer settings for uploading files
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/");
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  },
});

const upload = multer({ storage: storage });

//Defining routes and operations

app.get("/", (req, res) => {
  res.send("API is running");
});

// Routes for Todos
app.get("/api/todos", async (req, res) => {
  try {
    const todos = await Todo.findAll();
    res.json(todos);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to fetch todos" });
  }
});

app.post("/api/todos", async (req, res) => {
  try {
    const newTodo = await Todo.create(req.body);
    res.json(newTodo);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to create todo" });
  }
});

app.delete("/api/todos/:id", async (req, res) => {
  try {
    const todoId = parseInt(req.params.id, 10);
    await Todo.destroy({ where: { id: todoId } });
    res.sendStatus(204);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to delete todo" });
  }
});

// Routes for Calendar Events
app.get("/api/events", async (req, res) => {
  try {
    const events = await CalendarEvent.findAll();
    res.json(events);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to fetch events" });
  }
});

app.post("/api/events", async (req, res) => {
  try {
    const newEvent = await CalendarEvent.create(req.body);
    res.json(newEvent);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to create event" });
  }
});

app.delete("/api/events/:id", async (req, res) => {
  try {
    const eventId = parseInt(req.params.id, 10);
    await CalendarEvent.destroy({ where: { id: eventId } });
    res.sendStatus(204);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to delete event" });
  }
});

// Route for file uploads
app.post("/api/upload", upload.single("image"), (req, res) => {
  try {
    console.log("File received:", req.file);
    if (!req.file) {
      return res.status(400).json({ error: "No file uploaded" });
    }
    const imageUrl = `/uploads/${req.file.filename}`;
    res.json({ imageUrl });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to upload image" });
  }
});

// Route to get a list of images
app.get("/api/images", (req, res) => {
  const uploadsDir = path.join(__dirname, "uploads");
  fs.readdir(uploadsDir, (err, files) => {
    if (err) {
      return res.status(500).json({ error: "Failed to list images" });
    }
    const images = files.map((file) => `/uploads/${file}`);
    res.json(images);
  });
});

//Connecting to the database and starting the server
sequelize
  .authenticate()
  .then(() => {
    console.log("Connected to the database.");
    app.listen(port, () => {
      console.log(`Server is running on http://localhost:${port}`);
    });
  })
  .catch((error) => {
    console.error("Unable to connect to the database:", error);
  });
